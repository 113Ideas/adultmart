<?php

/**
 * @file
 */
?>
<?php echo $street_address; ?><br />
<?php echo $city .' '. $state .' '. $zip; ?><br />
<?php echo $country; ?>
