<?php
/**
 * @file
 * Provide display of name for the receipt types
 */
?>
<?php echo $name; ?>
