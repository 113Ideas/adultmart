<?php

/**
 * @file
 */
?>
<div class="price">
  <strong><?php echo $price_prefix; ?></strong> <?php echo $price; ?>
</div>
