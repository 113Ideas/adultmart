<?php

/**
 * @file
 */
?>
<div id="ec-product-feature-list-wrapper">
  <div class="ec-product-feature-list">
    <?php print $feature_list; ?>
  </div>
  <hr />
  <div class="ec-product-feature-add">
    <h3><?php print t('Add feature'); ?></h3>
    <?php print $feature_add; ?>
  </div>
</div>

