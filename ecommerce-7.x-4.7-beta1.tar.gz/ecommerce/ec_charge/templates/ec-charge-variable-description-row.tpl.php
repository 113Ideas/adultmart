<?php

/**
 * @file
 */
?>
<div>
  <strong>[<?php echo $key; ?>]</strong>
    <dt><?php echo $description; ?></dt>
</div>
