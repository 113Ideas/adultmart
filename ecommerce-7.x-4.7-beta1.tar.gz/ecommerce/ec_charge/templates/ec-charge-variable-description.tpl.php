<?php

/**
 * @file
 */
?>
<div>
  <?php echo implode("\n", $descriptions); ?>
</div>
