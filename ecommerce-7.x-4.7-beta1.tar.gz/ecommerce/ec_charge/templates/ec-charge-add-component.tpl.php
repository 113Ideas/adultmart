<?php

/**
 * @file
 */
?>
<div id="ec-charge-categories">
  <div id="ec-charge-categories-wrapper">
    <?php echo $categories; ?>
  </div>
</div>
<div id="ec-charge-components">
  <div id="ec-charge-compaonets-wrapper">
    <?php echo $components; ?>
  </div>
</div>
