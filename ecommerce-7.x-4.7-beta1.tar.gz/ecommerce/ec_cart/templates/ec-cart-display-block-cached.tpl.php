<?php

/**
 * @file
 */
?>
<div class="cart-link">
  <?php echo $cart_link ?>
</div>
