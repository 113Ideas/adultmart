<?php

/**
 * @file
 */
?>
<div class="item-count">
  <?php echo $item_count; ?>
</div>
<div class="cart-items">
  <!-- empty cart -->
</div>
