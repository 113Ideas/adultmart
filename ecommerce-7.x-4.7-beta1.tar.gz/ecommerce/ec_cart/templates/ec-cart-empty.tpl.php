<?php

/**
 * @file
 */
?>
<p><?php echo $empty_text; ?></p>
